# tidyverse packages
install.packages("ggplot2", "reshape2", "dplyr", "tidyr")

# outlier detectors
install.packages("devtools", "roahd", "mrfDepth", "rrcov", "CerioliOutlierDetection", "FUNTA", "ddalpha")
devtools::install_github("hhuang90/TVD")

# misc
install.packages("fdasrvf", "future", "future.apply", "tictoc", "xtable")
