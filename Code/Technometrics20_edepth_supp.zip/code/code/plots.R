library(reshape2)
library(ggplot2)
library(abind)

## plot objects
plt_funs = function(f, g, main = "Random Functions") {
  if(missing(g)) {
    h = f
    
    h.gg = melt(t(h))
    names(h.gg) = c("curve", "x", "y")
    
    plt = ggplot() +
      geom_path(data = h.gg, 
                aes(x, y, group = curve), 
                color = "#355c7d", 
                size = 0.6,
                alpha = 0.5) +
      theme_classic() +
      theme(plot.title = element_text(hjust = 0.5)) +
      theme(legend.position = "none") +
      xlab("X") +
      ylab("Y") +
      ggtitle(main)
    
    print(plt)
  }
  else {
    h = cbind(f, g)
    
    h.gg = melt(t(h))
    names(h.gg) = c("curve", "x", "y")
    h.gg["set"] = ifelse(h.gg$curve <= ncol(f), 1, 2)
    
    plt =  plt = ggplot() +
      geom_path(data = h.gg[h.gg$set == 1, ], 
                aes(x, y, group = curve), 
                color = "#355c7d", 
                size = 0.8,
                alpha = 0.5) +
      geom_path(data = h.gg[h.gg$set == 2, ], 
                aes(x, y, group = curve), 
                color = "red", 
                size = 1) +
      theme_classic() +
      theme(plot.title = element_text(hjust = 0.5)) +
      theme(legend.position = "none") +
      xlab("X") +
      ylab("Y") +
      ggtitle(main)
    
    print(plt)
  }
}
plt_trajs = function(f, g, main = "Random Trajectories") {
  
  if(missing(g)) {
    h = f
    
    h.x = melt(h[1,,])
    h.y = melt(h[2,,])
    
    h.gg = cbind(h.x[,2:3], h.y[,3])
    names(h.gg) = c("curve", "x", "y")
    
    plt = ggplot() +
      geom_path(data = h.gg,
                aes(x, y, group = curve),
                color = "#355c7d",
                size = 0.6,
                alpha = 0.5) +
      theme_classic() +
      theme(plot.title = element_text(hjust = 0.5)) +
      theme(legend.position = "none") +
      xlab("X") +
      ylab("Y") +
      ggtitle(main)
    
    print(plt)
  }
  else {
    h = abind(f, g, along = 3)
    
    h.x = melt(h[1,,])
    h.y = melt(h[2,,])
    
    h.gg = cbind(h.x[,2:3], h.y[,3])
    names(h.gg) = c("curve", "x", "y")
    h.gg["set"] = ifelse(h.gg$curve <= dim(f)[3], 1, 2)
    
    plt = ggplot() +
      geom_path(data = h.gg[h.gg$set == 1, ], 
                aes(x, y, group = curve), 
                color = "#355c7d", 
                size = 1,
                alpha = 0.5) +
      geom_path(data = h.gg[h.gg$set == 2, ], 
                aes(x, y, group = curve), 
                color = "red", 
                size = 1) +
      theme_classic() +
      theme(plot.title = element_text(hjust = 0.5)) +
      theme(legend.position = "none") +
      xlab("X") +
      ylab("Y") +
      ggtitle(main)
    
    print(plt)
  }
}

standardize = function(x) (x - min(x)) / (max(x) - min(x))
depth_boxplot = function(elastic_depths, alpha = 0.01, xlabel = "Component", ylabel = "Depth", main = "Elastic Depth Boxplot", ggobj = F) {
  
  Amplitude = elastic_depths$amplitude
  Phase = elastic_depths$phase
  depth.gg = melt(cbind(Amplitude, Phase))
  
  depth.quantiles = function(x) {
    q = c(max(x), max(x), max(x), quantile(x, 0.5), 
          max(quantile(x, 0.5)- 1.5*(max(x) - quantile(x, 0.5)), 0))
    names(q) = c("ymax", "upper", "middle", "lower", "ymin")
    q
  }
  
  amp.out = Amplitude[Amplitude < depth.quantiles(Amplitude)[5]]
  phs.out = Phase[Phase < depth.quantiles(Phase)[5]]
  out.gg = data.frame(value = c(amp.out, phs.out),
                      Var2 = c(rep("Amplitude", times = length(amp.out)),
                               rep("Phase", times = length(phs.out))))
  
  bplot = ggplot(depth.gg, aes(x=Var2, y=value, color=Var2)) +
    stat_summary(fun.data = depth.quantiles, geom = "boxplot", width=0.5) +
    geom_point(data = out.gg, aes(x=Var2, y=value, color=Var2)) +
    ylim(c(0, 1)) +
    theme_classic() +
    theme(plot.title = element_text(hjust = 0.5)) + 
    theme(legend.position="none") +
    theme(axis.title.y = element_blank()) +
    xlab(xlabel) +
    ylab(ylabel) +
    ggtitle(main) +
    coord_flip()
  
  if (ggobj == F) {
    print(bplot)
  }
  else return(bplot)
}



plt_outliers = function(f, outliers, main = "Outliers") {
  
  if (length(dim(f)) == 2) {
    h.gg = melt(t(f))
    
    names(h.gg) = c("curve", "x", "y")
    h.gg["set"] = ifelse(outliers, "out", "in")
    
    cc = scales::seq_gradient_pal("#ff6666", "#cc0000")(seq(0,1,length.out=sum(outliers)))
    cc = rep(cc, times = nrow(f))
  }
  
  if (length(dim(f)) > 2) {
    h = f
    h.x = melt(h[1,,])
    h.y = melt(h[2,,])
    
    h.gg = cbind(h.x[,2:3], h.y[,3])
    
    names(h.gg) = c("curve", "x", "y")
    h.gg["set"] = ifelse(rep(outliers, each = dim(f)[2]), "out", "in")
    
    cc = scales::seq_gradient_pal("#ff6666", "#cc0000")(seq(0,1,length.out=sum(outliers)))
    cc = rep(cc, each = dim(h)[2])
  }
  
  
  plt = ggplot() +
    geom_path(data = h.gg[h.gg$set == "in",], 
              aes(x, y, group = curve), 
              color = "#355c7d", 
              size = 0.5,
              alpha = 0.5) +
    geom_path(data = h.gg[h.gg$set == "out",], 
              aes(x, y, group = curve), 
              color = cc, 
              size = 1.2) +
    theme_classic() +
    theme(plot.title = element_text(hjust = 0.5)) +
    theme(legend.position = "none") +
    xlab("X") +
    ylab("Y") +
    ggtitle(main)
  
  print(plt)
}


