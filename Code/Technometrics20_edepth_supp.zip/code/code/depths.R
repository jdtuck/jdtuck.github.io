library(future)
library(future.apply)

# R1 depth
depth.R1 = function(fmat, time = seq(0, 1, length.out = nrow(fmat))) {
  # save the dimensions for convenience
  obs = nrow(fmat)
  fns = ncol(fmat)
  
  amp_dist = matrix(0, fns, fns)
  phs_dist = matrix(0, fns, fns)
  
  for (f1 in 1:(fns-1)) {
    
    dist = future_sapply(f1:ncol(fmat), function(y) {
      unlist(elastic.distance(fmat[,f1], fmat[,y], time))
    })
    
    phs_dist[f1, f1:fns] = dist[2,]
    amp_dist[f1, f1:fns] = dist[1,]
  }
  
  amp_dist = amp_dist + t(amp_dist)
  phs_dist = phs_dist + t(phs_dist)
  
  amp = 1 / (1 + apply(amp_dist, 1, median))
  phase = 1 / (1 + apply(phs_dist, 1, median))
  phase = ((2+pi)/pi) * (phase - 2/(2+pi))
  return(list(amplitude = amp, phase = phase))
}


# R2 depth
depth.R2 = function(curves) {
  
  fns = dim(curves)[3]
  
  amp_dist = matrix(0, fns, fns)
  phs_dist = matrix(0, fns, fns)
  
  for (f in 1:(fns-1)) {
    
    dist = future_sapply(f:fns, function(y) {
      unlist(elastic.distance.r2(curves[,,f], curves[,,y])) 
    })
    
    amp_dist[f, f:fns] = dist[2,]
    phs_dist[f, f:fns] = dist[1,]
  }
  
  amp_dist = amp_dist + t(amp_dist)
  phs_dist = phs_dist + t(phs_dist)
  
  amp = 1 / (1 + apply(amp_dist, 1, median))
  phase = 1 / (1 + apply(phs_dist, 1, median))
  phase = ((2+pi)/pi) * (phase - 2/(2+pi))
  return(list(amplitude = amp, phase = phase))
}

# S2 depth
depth.S2 = function(curves) {
  
  fns = dim(curves)[3]
  
  amp_dist = matrix(0, fns, fns)
  phs_dist = matrix(0, fns, fns)
  
  for (f in 1:(fns-1)) {
    dist = future_sapply(f:fns, function(y) {
      unlist(elastic.distance.s2(curves[,,f], curves[,,y])) 
    })
    
    phs_dist[f, f:fns] = dist[1,]
    amp_dist[f, f:fns] = dist[2,]
  }
  
  amp_dist = amp_dist + t(amp_dist)
  phs_dist = phs_dist + t(phs_dist)
  
  amp = 1 / (1 + apply(amp_dist, 1, median))
  phase = 1 / (1 + apply(phs_dist, 1, median))
  phase = ((2+pi)/pi) * (phase - 2/(2+pi))
  return(list(amplitude = amp, phase = phase))
}


##### outliers
bp_outliers = function(elastic_depths, ka = 1.8, thresh = 1) {
  amp = elastic_depths$amplitude
  phs = elastic_depths$phase
  
  amp.100 = max(amp)
  phs.100 = max(phs)
  
  amp.50 = as.numeric(quantile(amp, 0.5))
  phs.50 = as.numeric(quantile(phs, 0.5))
  
  amp.iqr = amp.100 - amp.50
  phs.iqr = phs.100 - phs.50
  
  amp.lim = max(amp.50 - ka*amp.iqr, 0)
  phs.lim = max(phs.50 - ka*phs.iqr, 0)
  
  amp.thre = as.numeric(quantile(amp, thresh))
  phs.thre = as.numeric(quantile(phs, thresh))
  
  amp.out = (amp < amp.lim)*(amp < amp.thre)
  phs.out = (phs < phs.lim)*(phs < phs.thre)
  
  return(list(amp = amp.out, phs = phs.out))
}




