library(fdasrvf)
library(reshape2)
library(ggplot2)
library(future)
library(future.apply)

##### Simulation
gp1d = function(fields = 100, mu = 0, sd = 1, l = 1, pts = 50) {
  grid = seq(0, 1, length.out = pts)
  distmat = as.matrix(dist(grid))
  
  # calc sigma with cov kernel
  sigma = exp(-distmat / l)
  
  sigma.eig = eigen(sigma)
  sigma.half = sigma.eig$vectors %*% diag(sqrt(sigma.eig$values)) %*% t(sigma.eig$vectors)
  
  gps = matrix(0, pts, fields)
  for(f in 1:fields) {
    gps[,f] = (sigma.half %*% rnorm(pts, sd = sd)) + mu
  }
  return(gps)
}

##### Plot
plt_funs = function(...) {
  # browser()
  
  # parse and format functions to be plotted 
  args = list(...)
  
  fmats = lapply(seq_along(args), function(x) cbind(melt(as.matrix(args[[x]])), x))
  fmats = do.call("rbind", fmats)
  fmats[["col"]] = as.factor(fmats[["x"]])
  fmats[["Var2"]] = paste0(fmats[["Var2"]], fmats[["col"]])
  
  plt = ggplot() +
    geom_line(data = fmats, aes(x = Var1, 
                                y = value, 
                                group = Var2, 
                                col = col),
              alpha = 0.9,
              size = 0.5) +
    theme_classic() +
    theme(plot.title = element_text(hjust = 0.5)) +
    theme(legend.position="none")
  
  print(plt)
}

##### Smoothing
smooth.traj = function(beta, sparam = 5) {
  beta.1 = smooth.data(beta[1,,], sparam)
  beta.2 = smooth.data(beta[2,,], sparam)
  aperm(abind(beta.1, beta.2, along = 3), c(3, 1, 2))
}

##### Depths and outliers
standardize = function(x) (x - min(x)) / (max(x) - min(x))
bp_outliers = function(elastic_depths, ka = 1.5, thresh = 1) {
  amp = elastic_depths$amplitude
  phs = elastic_depths$phase
  
  amp.100 = max(amp)
  phs.100 = max(phs)
  
  amp.50 = as.numeric(quantile(amp, 0.5))
  phs.50 = as.numeric(quantile(phs, 0.5))
  
  amp.iqr = amp.100 - amp.50
  phs.iqr = phs.100 - phs.50
  
  amp.lim = max(amp.50 - ka*amp.iqr, 0)
  phs.lim = max(phs.50 - ka*phs.iqr, 0)
  
  amp.thre = as.numeric(quantile(amp, thresh))
  phs.thre = as.numeric(quantile(phs, thresh))
  
  amp.out = (amp < amp.lim)*(amp < amp.thre)
  phs.out = (phs < phs.lim)*(phs < phs.thre)
  
  return(list(amp = amp.out, phs = phs.out))
}



##### Shapes / curves in R2
srsf = function(f) {
  f_to_srvf(f, seq(0, 1, length.out = length(f)))
}

elastic.distance.r2 = function(f1, f2) {
  align = curve_pair_align(f1, f2)
  
  # amplitude distance
  # amp = sqrt(mean(colSums((align$q1 - align$q2n)^2)))
  amp = calc_shape_dist(f1, f2)
  
  # phase distance
  phs = acos(min(1, mean(rep(1, length(align$gam)) * srsf(align$gam))))
  
  return(list(Dx = phs, Dy = amp))
}



##### trajectories on S
rescale = function(x) (x - min(x)) / (max(x) - min(x))


inner_s2 = function(f1, f2) {
  sum(diag(f1 %*% t(f2)))
}

norm_s2 = function(f) {
  sqrt(inner_s2(f, f))
}

inv_exp = function(f1, f2) {
  theta = acos(inner_s2(f1, f2))
  
  if ((is.nan(theta))|| (theta < 1e-10)){
    exp_inv = rep(0,length(f1))
  } else {
    exp_inv = theta / sin(theta) * (f2 - cos(theta)*f1)
  }
  return(exp_inv)
}


parallel_transport = function(h, p1, p2) {
  h - 2 * inner_s2(h, p2) * (p1 + p2) / norm_s2(p1 + p2)^2
}

backward_parallel_translation = function(p, v) {
  qp = v
  
  for(i in rev(2:nrow(p))) {
    qp = parallel_transport(qp, p[i, ], p[i-1, ])
  }
  
  qp
}

tsrvf = function(f) {
  t = nrow(f)
  n = ncol(f)
  
  adot = t(sapply(1:(t-1), function(x) (t-1) * inv_exp(f[x,], f[x+1,])))
  q = rbind(adot / sqrt(norm_s2(adot)), 0)
  
  q[t,] = parallel_transport(q[(t-1), ], f[t-1, ], f[t, ])
  
  q[2:t,] = sapply(2:t, function(x) backward_parallel_translation(f[1:x, ], q[x, ]))
  
  return(q)
}

warp_p_gam = function(p, gam) {
  pn = p
  t = seq(0, 1, length.out = nrow(p))
  for(i in 1:ncol(p)) {
    pn[,i] = approx(t, p[,i], gam)$y
  }
  return(pn)
}

pair_align_path = function(p1, p2) {
  h1 = tsrvf(p1)
  h2 = tsrvf(p2)
  
  n = nrow(h1)
  
  gam = .Call('DPQ', PACKAGE = 'fdasrvf', h1, h2, 3, n, 0, 0, rep(0,n))
  gam = rescale(invertGamma(gam))
  
  p2.warp = warp_p_gam(p2, gam)
  return(list(gam = gam, p2.warp = p2.warp))
}

elastic.distance.s2 = function(f, g) {
  
  # convert from the Rn format to the S2 format
  # really should have made these consistent from a get go...oh well
  f = t(f)
  g = t(g)
  align = pair_align_path(f, g)
  
  # amplitude dist
  amp = sqrt(mean((tsrvf(f) - tsrvf(align$p2.warp))^2))
  
  # phase dist
  ident = rep(1, nrow(f))
  phs = acos(min(mean(ident * srsf(align$gam)), 1))
  
  return(list(Dx = phs, Dy = amp))
}
