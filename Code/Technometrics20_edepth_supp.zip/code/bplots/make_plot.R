rm(list = ls())

library(ggplot2)
library(dplyr)
library(tidyr)
# library(xtable)

setwd("/Users/trevh/research/elastic-depth/submitted/revisions/bplots/out/")

files = list.files()

out_raw = readRDS(files[1])
for(f in files[-1]) {
  out_raw = rbind(out_raw, readRDS(f))
}


out = out_raw %>%
  filter(!model %in% c("pu", "saw")) %>%
  mutate(
    model = as.factor(model),
    model = recode(model, "au" = "Model 1",
                   "ad" = "Model 2",
                   "poly" = "Model 3",
                   "cov" = "Model 4",
                   "fu" = "Model 5",
                   "jmp" = "Model 6",
                   "pu" = "Model 7",
                   "saw" = "Model 8"),
    model = factor(model, levels = levels(model)[order(levels(model))]),
    Method = recode(method, "ED_A" = "ED-A",
                    "ED_B" = "ED-B",
                    "ED_P" = "ED-P")
    
  ) %>%
  filter(Method != "ED-B")


ggplot(out) +
  geom_boxplot(aes(x = Method, y = f1, group = Method)) +
  geom_boxplot(data = out[out$Method == "ED-A",], 
               aes(x = Method, y = f1),
               color = "#F8766D") +
  facet_wrap(. ~ model) +
  ylab("F1 Score") +
  xlab("Method") +
  theme_bw() +
  theme(axis.text.x = element_text(vjust = 0.85, angle = 90))

ggsave("../methods.png", height = 5, width = 7)


# Just the good ones
out_sub = out %>%
  filter(Method %in% c("ED-A", "TVD", "GEOM", "MS", "DIR"))


# ggplot(out_sub) +
#   geom_boxplot(aes(x = method, y = f1, fill = Method)) +
#   facet_wrap(. ~ model) +
#   ylab("F1 Score") +
#   theme_bw()


ggplot(out_sub) +
  geom_boxplot(aes(x = Method, y = f1, group = Method)) +
  geom_boxplot(data = out_sub[out_sub$Method == "ED-A",], 
               aes(x = Method, y = f1),
               color = "#F8766D") +
  facet_wrap(. ~ model) +
  ylab("F1 Score") +
  xlab("Method") +
  theme_bw()
ggsave("../best_methods.png", height = 4, width = 7)





# phase
out_phase = out_raw %>%
  filter(model ==  "pu") %>%
  mutate(
    model = as.factor(model),
    model = recode(model, "au" = "Model 1",
                   "ad" = "Model 2",
                   "poly" = "Model 3",
                   "cov" = "Model 4",
                   "fu" = "Model 5",
                   "jmp" = "Model 6",
                   "pu" = "Model 7",
                   "saw" = "Model 8"),
    model = factor(model, levels = levels(model)[order(levels(model))]),
    Method = recode(method, "ED_A" = "ED-A",
                    "ED_B" = "ED-B",
                    "ED_P" = "ED-P")
  ) %>%
  filter(Method != "ED-B")


ggplot(out_phase) +
  geom_boxplot(aes(x = Method, y = f1, group = Method)) +
  geom_boxplot(data = out_phase[out_phase$Method == "ED-P",], 
               aes(x = Method, y = f1),
               color = "#F8766D") +
  ylab("F1 Score") +
  xlab("Method") +
  facet_wrap(. ~ model) +
  theme_bw() +
  theme(text = element_text(size=20)) +
  theme(axis.text.x = element_text(vjust = 0.85, angle = 90))
ggsave("../phase_methods_all.png", height = 4, width = 7)


out_phase = out_phase %>%
  filter(Method %in% c("ED-P", "TVD", "GEOM", "MS", "DIR"))

ggplot(out_phase) +
  geom_boxplot(aes(x = Method, y = f1, group = Method)) +
  geom_boxplot(data = out_phase[out_phase$Method == "ED-P",], 
               aes(x = Method, y = f1),
               color = "#F8766D") +
  ylab("F1 Score") +
  xlab("Method") +
  facet_wrap(. ~ model) +
  theme_bw() +
  theme(text = element_text(size=20))
ggsave("../phase_methods.png", height = 4, width = 7)

