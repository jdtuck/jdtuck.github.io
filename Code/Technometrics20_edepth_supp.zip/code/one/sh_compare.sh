#!/bin/bash

# simulate with and without phase for each of the 8 models

for bat in {1..10}; do
for var in au ad pu cov fu jmp poly; do

qsub -v VAR=$var,PHS=p,TRN=t,BAT=$bat pbs_compare.pbs

done
done
