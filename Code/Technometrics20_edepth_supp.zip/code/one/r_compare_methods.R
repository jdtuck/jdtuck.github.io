rm(list = ls()); gc()

library(tictoc)
library(fdasrvf)
library(reshape2)
library(ggplot2)
library(future)
library(future.apply)

# other outlier detectors
library(roahd)
library(mrfDepth)
library(TVD)
library(rrcov)
library(CerioliOutlierDetection)
library(FUNTA)
library(ddalpha)

# simulation and depth code
setwd("/home/trevorh2/elastic/bplots")
source("/home/trevorh2/elastic/utils/sim.R")
source("/home/trevorh2/elastic/utils/depths.R")
source("/home/trevorh2/elastic/utils/plots.R")
source("/home/trevorh2/elastic/utils/utils.R")

# Directional quantile
fdq = function(h) {
  h = t(h)
  out = fOutl(array(h, dim = c(pts, ncol(h), 1)), diagnostic = T, 
              type = "fDO", distOptions = list(seed = runif(1, 1, 1000000)))
  as.vector(1 / (1 + out$fOutlyingnessX))
}

# Magnitude scale plot
proj.depth = function(x) {
  sdo = (x - median(x)) / mad(x)
  1 / (1 + sdo)
}
direct = function(d, x) {
  o = 1 / (d - 1)
  o = o * (x - median(x)) / sqrt(sum((x-median(x))^2))
}
ms.o = function(f) {
  apply(f, 1, function(x) direct(proj.depth(x), x))
}
ms.mo = function(f) {
  apply(ms.o(f), 1, mean)
}
ms.vo = function(f) {
  o = ms.o(f)
  mo = ms.mo(f)
  
  sapply(1:ncol(f), function(x) mean((o[x,] - mo[x])^2))
}

#NAGY
nagy = function(fmat, j = 2) {
  hdataf = rawfd2dataf(t(fmat), range = c(0, 1))
  hdepth = depthf.fd1(hdataf, hdataf, order = j)
  
  return(list(fdj = hdepth$Half_FD, idj = hdepth$Half_ID))
}


# directional outliers
DirOut=function(data,DirOutmatrix=FALSE,h=0.55,method="Mah"){
  temp=dim(data)
  #####################
  #Univariate cases   #
  #####################
  
  if (length(temp)==2)
  {
    
    data=t(data)
    p=dim(data)[1]
    n=dim(data)[2]
    Dirout=matrix(0,n,p)
    dmat=matrix(0,p,n)
    medvec=apply(data,1,median)
    madvec=apply(data,1,mad)
    outmat=abs((data-medvec)/(madvec))
    signmat=sign((data-medvec))
    Dirout=t(outmat*signmat)
    out_avr=apply(Dirout,1,mean)
    out_var=apply(Dirout,1,var)
    M=cbind(out_avr,out_var)
    ans=cov.rob(M,method="mcd",nsamp="best",quantile.used=floor(n*h))
    cov=ans$cov
    me=ans$center
    D=mahalanobis(M,me,cov)
  }
  
  #####################
  #Multivariate cases #
  #####################
  
  
  if (length(temp)==3)
  {
    n=temp[1]
    p=temp[2]
    d=temp[3]
    Dirout=array(0,dim=c(n,p,d))
    for (j in 1:p)
    {
      temp=covMcd(data[,j,], alpha = 0.51,control = rrcov.control(alpha=0.95))
      me=temp$center
      if (method=="Mah")
      {
        out=mahalanobis(data[,j,],temp$center,temp$cov)
      }
      
      if (method=="SDO")
      {
        out=adjOutlyingness(data[,j,],clower=0,cupper=0)$adjout
      }
      for (i in 1:n)
      {
        if ((sum((data[i,j,]-me)^2))^(1/2)==0)
        {
          Dirout[i,j,]=rep(0,d)
        }
        else{
          dir=(data[i,j,]-me)/(sum((data[i,j,]-me)^2))^(1/2)
          Dirout[i,j,]=dir*out[i]
        }
      }
    }
    out_avr=apply(Dirout,c(1,3),mean)
    out_var=apply(Dirout^2,1,mean)*d-apply(out_avr^2,1,sum)
    M=cbind(out_avr,out_var)
    ans=cov.rob(M,method="mcd",nsamp="best",quantile.used=floor(n*h))
    cov=ans$cov
    me=ans$center
    D=mahalanobis(M,me,cov)
  }
  
  if (DirOutmatrix)
    list(D=D,Dirout=Dirout,out_avr=out_avr,out_var=out_var)
  else 
    list(D=D,out_avr=out_avr,out_var=out_var)
}
dir.rank = function(h) {
  fac=0.154
  cutoff=6.91
  
  n=dim(t(h))[1]
  p=dim(t(h))[2]
  
  results=DirOut(t(h))
  M=cbind(results$out_avr,results$out_var)
  ans=cov.rob(M,method="mcd",nsamp="best",quantile.used=floor(n*0.55))
  cov=ans$cov
  me=ans$center
  D=mahalanobis(M,me,cov)
  
  rank(1/(fac*D))
}


# geomboxplots
geom.rank = function(h) {
  h.warp = time_warping(h, t, showplot = F, method = "median")
  rank(1 / sapply(1:100, function(x) sum((h.warp$qn[,x]- h.warp$fmean[,1])^2)))
}



# outlier metrics
plan(multiprocess)
rank_anomaly = function(h) {
  
  # depth boxplot
  depths = depth.R1(h)
  amp.out = rank(depths$amplitude)[100]
  phs.out = rank(depths$phase)[100]
  eld.out = min(amp.out, phs.out)
  
  # outliergram
  ogram = outliergram( fData(t, t(h)), display = F)
  ogram.out = rank(1 - ogram$d)[100]
  
  # sequential transformation T0
  seqtrans1 = apply(h, 2, function(x) x - mean(x))
  seq1_out = fbplot(fData(t, t(seqtrans1)), Depths = "fdq", display = F)$Depth
  seq1_out = rank(seq1_out)[100]
  
  # sequential transformation T1
  seqtrans2 = apply(seqtrans1, 2, function(x) x / sqrt(mean(x^2)))
  seq2_out = fbplot(fData(t, t(seqtrans2)), Depths = "fdq", display = F)$Depth
  seq2_out = rank(seq2_out)[100]
  
  # sequential transformation D1
  seqtrans3 = apply(h, 2, function(x) diff(x) / diff(t))
  seq3_out = fbplot(fData(t[-1], t(seqtrans3)), Depths = "fdq", display = F)$Depth
  seq3_out = rank(seq3_out)[100]
  
  # Functional Outlier Map (FOM)
  fomplot = fom(fOutl(array(h, dim = c(pts, ncol(h), 1)), diagnostic = T, 
                      type = "fDO", distOptions = list(seed = runif(1, 1, 1000000))), cutoff = TRUE)
  fom_out = min(rank(max(fomplot$data$DispMeasure) - fomplot$data$DispMeasure)[100],
                rank(max(fomplot$data$fAO) - fomplot$data$fAO)[100])
  
  # Total Variation Depth (TVD)
  tvd = TVD::detectOutlier(h, ncol(h), nrow(h), empFactor = 1.5)
  tvd_out = rank(tvd$MSS)[100]
  # tvd_out = 1
  
  # Magnitude scale plot
  msm = ms.mo(h)
  msv = ms.vo(h)
  ms = cbind(msm, msv)
  ms = cerioli2010.irmcd.test(ms, signif.gamma = 1-0.993)
  ms_out = rank(1 - ms$mahdist.rw)[100]
  
  # rFUNTA
  funta_out = rank(rFUNTA(t(h)))[100]
  
  # FDJ outliers
  nagy_out = nagy(h)
  fdj_out = rank(nagy_out$fdj)[100]
  idj_out = rank(nagy_out$idj)[100]
  
  
  # directional outliers
  dir_out = dir.rank(h)[100]
  
  # geom boxplots
  geom_out = geom.rank(h)[100]
  
  
  cbind(amp.out,
        phs.out,
        eld.out,
        ogram.out,
        seq1_out,
        seq2_out,
        seq3_out,
        fom_out,
        tvd_out,
        ms_out,
        funta_out,
        fdj_out,
        idj_out,
        dir_out,
        geom_out)
}

# input 
args = commandArgs(TRUE)
outmodel = as.character(args[1])
phase = as.character(args[2])
trans = as.character(args[3])
batch = as.integer(args[4])

# for modifying the seed in a consistent way
str2num = function(string) {
  as.numeric(paste(match(unlist(strsplit(outmodel, "")), letters[1:26]), collapse = ""))
}

# unchanging parameters
set.seed((0723 + str2num(outmodel) + str2num(phase))*batch)
sims = 100
pts = 30

slope = 4
std = 0.5
l = 0.5
fac = 6

# intermediate variables
t = seq(0, 1, length.out = pts)
outs = matrix(0, sims, 15)


#### Simulation
for(i in 1:sims) {
  tic(paste0("sim ", i)) 
  
  # generate data according to outlier model
  if(outmodel == "au") {
    f = gp1d(99, mu = sin(5*t*pi) + slope*t, sd = std, l = l, pts = pts)
    g = gp1d(1, mu = fac/1.5*sin(5*t*pi) + slope*t, sd = std, l = l, pts = pts)
    
    if(phase == "p") {
      # add phase
      fgam = t(rgam(pts, 0.1, 99))
      ggam = t(rgam(pts, 0.1, 10))
      
      f = vapply(1:ncol(f), function(x) warp_f_gamma(f[,x], t, fgam[,x]), rep(0, pts))
      g = vapply(1:ncol(g), function(x) warp_f_gamma(g[,x], t, ggam[,x]), rep(0, pts))
    }
    
    # random shifting
    f = vapply(1:ncol(f), function(x) f[,x] + rnorm(1, sd = 1), rep(0, pts))
    g = vapply(1:ncol(g), function(x) g[,x] + rnorm(1, sd = 1), rep(0, pts))
    
    h = cbind(f, g)
  }
  if(outmodel == "ad") {
    f = gp1d(99, mu = sin(5*t*pi) + slope*t, sd = std, l = l, pts = pts)
    g = gp1d(1, mu = (1/fac)*sin(5*t*pi) + slope*t, sd = std, l = l, pts = pts)
    
    if(phase == "p") {
      # add phase
      fgam = t(rgam(pts, 0.1, 99))
      ggam = t(rgam(pts, 0.1, 10))
      
      f = vapply(1:ncol(f), function(x) warp_f_gamma(f[,x], t, fgam[,x]), rep(0, pts))
      g = vapply(1:ncol(g), function(x) warp_f_gamma(g[,x], t, ggam[,x]), rep(0, pts))
    }
    
    # random shifting
    f = vapply(1:ncol(f), function(x) f[,x] + rnorm(1, sd = 1), rep(0, pts))
    g = vapply(1:ncol(g), function(x) g[,x] + rnorm(1, sd = 1), rep(0, pts))
    
    h = cbind(f, g)
  }
  if(outmodel == "pu") {
    f = gp1d(99, mu = sin(5*t*pi) + slope*t, sd = std, l = l, pts = pts)
    g = gp1d(1, mu = sin(5*t*pi) + slope*t, sd = std, l = l, pts = pts)
    
    gam = t(rgam(pts, fac, 10))
    g = vapply(1:ncol(g), function(x) warp_f_gamma(g[,x], t, gam[,x]), rep(0, pts))
    
    h = cbind(f, g)
  }
  if(outmodel == "cov") {
    f = gp1d(99, mu = sin(5*t*pi) + slope*t, sd = std, l = fac*l, pts = pts)
    g = gp1d(1, mu = sin(5*t*pi) + slope*t, sd = std, l = l/fac, pts = pts)
    
    if(phase == "p") {
      # add phase
      fgam = t(rgam(pts, 0.1, 99))
      ggam = t(rgam(pts, 0.1, 10))
      
      f = vapply(1:ncol(f), function(x) warp_f_gamma(f[,x], t, fgam[,x]), rep(0, pts))
      g = vapply(1:ncol(g), function(x) warp_f_gamma(g[,x], t, ggam[,x]), rep(0, pts))
    }
    
    # random shifting
    f = vapply(1:ncol(f), function(x) f[,x] + rnorm(1, sd = 1), rep(0, pts))
    g = vapply(1:ncol(g), function(x) g[,x] + rnorm(1, sd = 1), rep(0, pts))
    
    h = cbind(f, g)
  }
  if(outmodel == "fu") {
    f = gp1d(99, mu = sin(2*t*pi) + slope*t, sd = std, l = l, pts = pts)
    g = gp1d(1, mu = sin(2*fac*t*pi) + slope*t, sd = std, l = l, pts = pts)
    
    if(phase == "p") {
      # add phase
      fgam = t(rgam(pts, 0.1, 99))
      ggam = t(rgam(pts, 0.1, 10))
      
      f = vapply(1:ncol(f), function(x) warp_f_gamma(f[,x], t, fgam[,x]), rep(0, pts))
      g = vapply(1:ncol(g), function(x) warp_f_gamma(g[,x], t, ggam[,x]), rep(0, pts))
    }
    
    # random shifting
    f = vapply(1:ncol(f), function(x) f[,x] + rnorm(1, sd = 1), rep(0, pts))
    g = vapply(1:ncol(g), function(x) g[,x] + rnorm(1, sd = 1), rep(0, pts))
    
    h = cbind(f, g)
  }
  if(outmodel == "fd") {
    f = gp1d(99, mu = sin(2*fac*t*pi) + slope*t, sd = std, l = l, pts = pts)
    g = gp1d(1, mu = sin(2*t*pi) + slope*t, sd = std, l = l, pts = pts)
    
    if(phase == "p") {
      # add phase
      fgam = t(rgam(pts, 0.1, 99))
      ggam = t(rgam(pts, 0.1, 10))
      
      f = vapply(1:ncol(f), function(x) warp_f_gamma(f[,x], t, fgam[,x]), rep(0, pts))
      g = vapply(1:ncol(g), function(x) warp_f_gamma(g[,x], t, ggam[,x]), rep(0, pts))
    }
    
    # random shifting
    f = vapply(1:ncol(f), function(x) f[,x] + rnorm(1, sd = 1), rep(0, pts))
    g = vapply(1:ncol(g), function(x) g[,x] + rnorm(1, sd = 1), rep(0, pts))
    
    h = cbind(f, g)
  }
  if(outmodel == "sup") {
    f = gp1d(99, mu = sin(5*t*pi) + slope*t, sd = std, l = l, pts = pts)
    g = 0.5*gp1d(1, mu = sin(2*fac*t*pi) + slope*t, sd = std, l = l, pts = pts) +
        0.5*gp1d(1, mu = sin(5*t*pi) + slope*t, sd = std, l = l, pts = pts)
    
    if(phase == "p") {
      # add phase
      fgam = t(rgam(pts, 0.1, 99))
      ggam = t(rgam(pts, 0.1, 10))
      
      f = vapply(1:ncol(f), function(x) warp_f_gamma(f[,x], t, fgam[,x]), rep(0, pts))
      g = vapply(1:ncol(g), function(x) warp_f_gamma(g[,x], t, ggam[,x]), rep(0, pts))
    }
    
    # random shifting
    f = vapply(1:ncol(f), function(x) f[,x] + rnorm(1, sd = 1), rep(0, pts))
    g = vapply(1:ncol(g), function(x) g[,x] + rnorm(1, sd = 1), rep(0, pts))
    
    h = cbind(f, g)
  }
  if(outmodel == "pk") {
    f = gp1d(99, mu = sin(5*t*pi) + slope*t, sd = std, l = l, pts = pts)
    g = gp1d(1, mu = sin(5*t*pi) + slope*t, sd = std, l = l, pts = pts)
    
    tl = round(runif(1, 0.3, 0.6) * pts, 0)
    tu = round(tl + 0.2 * pts, 0)
    
    jumps = matrix(0, pts, 1)
    for(j in 1:1) {
      jumps[seq(tl[j], tu[j]), j] = 3
    }
    g = g + jumps
    
    if(phase == "p") {
      # add phase
      fgam = t(rgam(pts, 0.1, 99))
      ggam = t(rgam(pts, 0.1, 10))
      
      f = vapply(1:ncol(f), function(x) warp_f_gamma(f[,x], t, fgam[,x]), rep(0, pts))
      g = vapply(1:ncol(g), function(x) warp_f_gamma(g[,x], t, ggam[,x]), rep(0, pts))
    }
    
    # random shifting
    f = vapply(1:ncol(f), function(x) f[,x] + rnorm(1, sd = 1), rep(0, pts))
    g = vapply(1:ncol(g), function(x) g[,x] + rnorm(1, sd = 1), rep(0, pts))
    
    h = cbind(f, g)
  }
  if(outmodel == "jmp") {
    f = gp1d(99, mu = sin(5*t*pi) + slope*t, sd = std, l = l, pts = pts)
    g = gp1d(1, mu = sin(5*t*pi) + slope*t, sd = std, l = l, pts = pts)
    
    tl = round(runif(1, 0.4, 0.6) * pts, 0)
    
    jumps = matrix(0, pts, 1)
    for(j in 1:1) {
      jumps[seq(1, tl[j]-1), j] = -2
      jumps[seq(tl[j], nrow(g)), j] = 3
    }
    g = g + jumps
    
    if(phase == "p") {
      # add phase
      fgam = t(rgam(pts, 0.1, 99))
      ggam = t(rgam(pts, 0.1, 10))
      
      f = vapply(1:ncol(f), function(x) warp_f_gamma(f[,x], t, fgam[,x]), rep(0, pts))
      g = vapply(1:ncol(g), function(x) warp_f_gamma(g[,x], t, ggam[,x]), rep(0, pts))
    }
    
    # random shifting
    f = vapply(1:ncol(f), function(x) f[,x] + rnorm(1, sd = 1), rep(0, pts))
    g = vapply(1:ncol(g), function(x) g[,x] + rnorm(1, sd = 1), rep(0, pts))
    
    h = cbind(f, g)
  }
  if(outmodel == "poly") {
    t_poly = seq(-1, 1, length.out = pts)
    
    f = gp1d(99, mu = 1*t_poly^3 - 2*t_poly^2 + 0.5*t_poly, sd = std, l = l, pts = pts)
    f = f - mean(f)
    
    g = gp1d(1, mu = 2*t_poly^3 + 1*t_poly^2 - 0.5*t_poly, sd = std, l = l, pts = pts)
    g = g - mean(g)
    
    if(phase == "p") {
      # add phase
      fgam = t(rgam(pts, 0.1, 99))
      ggam = t(rgam(pts, 0.1, 10))
      
      f = vapply(1:ncol(f), function(x) warp_f_gamma(f[,x], t, fgam[,x]), rep(0, pts))
      g = vapply(1:ncol(g), function(x) warp_f_gamma(g[,x], t, ggam[,x]), rep(0, pts))
    }
    
    # random shifting
    f = vapply(1:ncol(f), function(x) f[,x] + rnorm(1, sd = 1), rep(0, pts))
    g = vapply(1:ncol(g), function(x) g[,x] + rnorm(1, sd = 1), rep(0, pts))
    
    h = cbind(f, g)
  }
  
  # Add translation "outliers" as bait
  if(trans == "t") {
    trans.ind = sample(1:100, size = 10, replace = F)
    
    h[,trans.ind] = vapply(trans.ind, function(x) {
      h[,x] + sample(c(-10, 10),1)
    }, FUN.VALUE = rep(0, pts))
  }
  
  # find outliers with each of the methods
  outs[i,] = rank_anomaly(h)
  toc()
}

# summarize and output outlier FNR and FPR metrics
outliers = melt(outs)
names(outliers) = c("sims", "method", "rank")
outliers[["sims"]] = 1:sims
outliers[["method"]] = rep(c("ED_A", "ED_P", "ED_B", "OG", "ST-T1", 
                             "ST-T2", "ST-D1", "FOM", "TVD", "MS", "rFUNTA",
                             "FDJ", "IDJ", "DIR", "GEOM"), each = sims)
outliers[["model"]] = outmodel
outliers[["phase"]] = phase
outliers[["trans"]] = trans
saveRDS(outliers, paste0("/home/trevorh2/elastic/one/out/out_", 
                         outmodel, "_", phase, "_", trans, "_", batch, "_.rds"))
