set.seed(0723)

da = c(0.2, 0.25, 0.3, rnorm(100, mean = 0.6, sd = 0.05))

d_med = max(da)
d_iqr = abs(median(da) - d_med)
d_cut = median(da) - 1.5*d_iqr


Amplitude = da
depth.gg = melt(da)
depth.gg[["ind"]] = 1

depth.quantiles = function(x) {
  q = c(max(x), max(x), max(x), median(x), 
        median(x) - 1.5*(abs(median(x) - max(x))))
  names(q) = c("ymax", "upper", "middle", "lower", "ymin")
  q
}

depth.quantiles(da)

amp.out = Amplitude[Amplitude < depth.quantiles(Amplitude)[5]]
out.gg = melt(amp.out)
out.gg[["ind"]] = 1

lilarrow = arrow(type="closed", length = unit(0.15, "cm"))

ggplot(depth.gg, aes(x=ind, y=value)) +
  stat_summary(fun.data = depth.quantiles, geom = "boxplot", width=0.4) +
  geom_point(data = out.gg, aes(x=ind, y=value)) +
  geom_segment(aes(x = 0.9, y = d_cut, xend = 1.1, yend = d_cut)) +
  geom_text(x=1.4, y=0.20, label="Shape outliers") +
  geom_segment(aes(x = 1.35, y = 0.2, xend = 1.05, yend = 0.2), arrow=lilarrow) +
  geom_segment(aes(x = 1.35, y = 0.2, xend = 1.05, yend = 0.25), arrow=lilarrow) +
  geom_segment(aes(x = 1.35, y = 0.2, xend = 1.05, yend = 0.3), arrow=lilarrow) +
  geom_text(x=1.4, y=d_cut, label="Whisker (c)") +
  geom_segment(aes(x = 1.35, y = d_cut, xend = 1.15, yend = d_cut), arrow=lilarrow) +
  geom_text(x=1.4, y=median(da)-0.01, label="IQR") +
  geom_segment(aes(x = 1.35, y = median(da), xend = 1.25, yend = median(da)), arrow=lilarrow) +
  geom_segment(aes(x = 1.35, y = median(da), xend = 1.25, yend = d_med-0.01), arrow=lilarrow) +
  geom_text(x=1.4, y=d_med+0.05, label="Depth median") +
  geom_segment(aes(x = 1.35, y = max(da)+0.05, xend = 1.25, yend = d_med), arrow=lilarrow) +
  geom_rug(sides="l") +
  geom_text(x=0.65, y=d_med-0.05, label="Depth values") +
  geom_segment(aes(x = 0.6, y = max(da)-0.05, xend = 0.51, yend = max(da)-0.08), arrow=lilarrow) +
  ylim(c(0, 1)) +
  xlim(c(0.5, 1.5)) +
  theme_classic() +
  theme(axis.title.y = element_blank(),
        axis.text.y = element_blank(),
        axis.ticks.y = element_blank(),
        text = element_text(size=20)) +
  coord_flip() +
  ylab("Amplitude depth")
ggsave("../../diagram.png", width = 8, height = 4)


