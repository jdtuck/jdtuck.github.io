# Directional quantile
fdq = function(h) {
  h = t(h)
  out = fOutl(array(h, dim = c(pts, ncol(h), 1)), diagnostic = T, 
              type = "fDO", distOptions = list(seed = runif(1, 1, 1000000)))
  as.vector(1 / (1 + out$fOutlyingnessX))
}

# Magnitude scale plot
proj.depth = function(x) {
  sdo = (x - median(x)) / mad(x)
  1 / (1 + sdo)
}
direct = function(d, x) {
  o = 1 / (d - 1)
  o = o * (x - median(x)) / sqrt(sum((x-median(x))^2))
}
ms.o = function(f) {
  apply(f, 1, function(x) direct(proj.depth(x), x))
}
ms.mo = function(f) {
  apply(ms.o(f), 1, mean)
}
ms.vo = function(f) {
  o = ms.o(f)
  mo = ms.mo(f)
  
  sapply(1:ncol(f), function(x) mean((o[x,] - mo[x])^2))
}

#FUNTA 
rFUNTArep = function(fmat, weights = rFUNTA(fmat), gam = 0.05) {
  fields = nrow(fmat)
  pts = ncol(fmat)
  sigma = gam*cov(fmat)
  sigma.cho = t(chol(sigma))
  
  gps = matrix(0,fields, pts)
  for(f in 1:fields) {
    gps[f,] = (sigma.cho %*% rnorm(pts))
  }
  
  fmat[sample(1:fields, fields, TRUE, weights),] + gps
  # gps
}
rFUNTAboot = function(fmat, weights = rFUNTA(fmat), nboot = 100) {
  cutoff = future_sapply(1:nboot, function(x) {
    k = rFUNTArep(fmat, weights)
    kfunta = rFUNTA(k)
    as.numeric(quantile(kfunta, probs = 0.01))
  })
  
  median(cutoff)
}
rFUNTAoutliers = function(fmat) {
  fmat = t(fmat)
  
  depths = rFUNTA(fmat)
  cutoff = rFUNTAboot(fmat, depths)
  
  outs = rep(0, nrow(fmat))
  outs[depths < cutoff] = 1
  
  return(outs)
}

#NAGY
nagy = function(fmat, j = 2) {
  hdataf = rawfd2dataf(t(fmat), range = c(0, 1))
  hdepth = depthf.fd1(hdataf, hdataf, order = j)
  
  return(list(fdj = hdepth$Half_FD, idj = hdepth$Half_ID))
}
nagy_outliers = function(fmat) {
  d1 = nagy(h, 1)
  d2 = nagy(h, 2)
  
  sj.fdj = -log(d2$fdj / d1$fdj)
  
  cutoff = 1.5*IQR(sj.fdj) + as.numeric(quantile(sj.fdj, 0.75))
  cufoff = max(sj.fdj[sj.fdj < cutoff])
  fdj = as.numeric(sj.fdj >= cutoff) 
  
  
  sj.idj = -log(d2$idj / d1$idj)
  
  cutoff = 1.5*IQR(sj.idj) + as.numeric(quantile(sj.idj, 0.75))
  cufoff = max(sj.idj[sj.idj < cutoff])
  idj = as.numeric(sj.idj >= cutoff) 
  
  return(list(fdj = fdj, idj = idj))
}

# directional outliers
DirOut=function(data,DirOutmatrix=FALSE,h=0.55,method="Mah"){
  temp=dim(data)
  #####################
  #Univariate cases   #
  #####################
  
  if (length(temp)==2)
  {
    
    data=t(data)
    p=dim(data)[1]
    n=dim(data)[2]
    Dirout=matrix(0,n,p)
    dmat=matrix(0,p,n)
    medvec=apply(data,1,median)
    madvec=apply(data,1,mad)
    outmat=abs((data-medvec)/(madvec))
    signmat=sign((data-medvec))
    Dirout=t(outmat*signmat)
    out_avr=apply(Dirout,1,mean)
    out_var=apply(Dirout,1,var)
    M=cbind(out_avr,out_var)
    ans=cov.rob(M,method="mcd",nsamp="best",quantile.used=floor(n*h))
    cov=ans$cov
    me=ans$center
    D=mahalanobis(M,me,cov)
  }
  
  #####################
  #Multivariate cases #
  #####################
  
  
  if (length(temp)==3)
  {
    n=temp[1]
    p=temp[2]
    d=temp[3]
    Dirout=array(0,dim=c(n,p,d))
    for (j in 1:p)
    {
      temp=covMcd(data[,j,], alpha = 0.51,control = rrcov.control(alpha=0.95))
      me=temp$center
      if (method=="Mah")
      {
        out=mahalanobis(data[,j,],temp$center,temp$cov)
      }
      
      if (method=="SDO")
      {
        out=adjOutlyingness(data[,j,],clower=0,cupper=0)$adjout
      }
      for (i in 1:n)
      {
        if ((sum((data[i,j,]-me)^2))^(1/2)==0)
        {
          Dirout[i,j,]=rep(0,d)
        }
        else{
          dir=(data[i,j,]-me)/(sum((data[i,j,]-me)^2))^(1/2)
          Dirout[i,j,]=dir*out[i]
        }
      }
    }
    out_avr=apply(Dirout,c(1,3),mean)
    out_var=apply(Dirout^2,1,mean)*d-apply(out_avr^2,1,sum)
    M=cbind(out_avr,out_var)
    ans=cov.rob(M,method="mcd",nsamp="best",quantile.used=floor(n*h))
    cov=ans$cov
    me=ans$center
    D=mahalanobis(M,me,cov)
  }
  
  if (DirOutmatrix)
    list(D=D,Dirout=Dirout,out_avr=out_avr,out_var=out_var)
  else 
    list(D=D,out_avr=out_avr,out_var=out_var)
}
dir.out = function(h) {
  DirOut(t(h))
  fac=0.154
  cutoff=6.91
  
  n=dim(t(h))[1]
  p=dim(t(h))[2]
  
  results=DirOut(t(h))
  M=cbind(results$out_avr,results$out_var)
  ans=cov.rob(M,method="mcd",nsamp="best",quantile.used=floor(n*0.55))
  cov=ans$cov
  me=ans$center
  D=mahalanobis(M,me,cov)
  num=sum(fac*D>cutoff)
  
  which(fac*D>cutoff)
}

# geomboxplots
geom.bplot = function(h) {
  h.warp = time_warping(h, t, showplot = F, method = "median")
  AmplitudeBoxplot(h.warp, showplot = F)$outlier_index
}