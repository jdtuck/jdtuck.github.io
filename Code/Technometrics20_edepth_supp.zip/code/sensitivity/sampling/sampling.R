rm(list = ls()); gc()

setwd("/Users/trevh/research/elastic-depth/submitted/")

setwd("/Users/trevorh2/research/elastic-depth/submitted/")

library(tictoc)
library(fdasrvf)
library(reshape2)
library(ggplot2)
library(future.apply)

# simulation and depth code
source("utils.R")
source("depths.R")

plot.frequency.spectrum <- function(X.k, xlimits=c(0,length(X.k))) {
  plot.data  <- cbind(0:(length(X.k)-1), Mod(X.k))
  plot.data[2:length(X.k),2] <- 2*plot.data[2:length(X.k),2] 
  
  plot(plot.data, t="h", lwd=2, main="", 
       xlab="Frequency (Hz)", ylab="Strength", 
       xlim=xlimits, ylim=c(0,max(Mod(plot.data[,2]))))
}

skew = function(d) {
  mean(((d - mean(d))/sd(d))^3)
}

set.seed(1022)

# unchanging parameters
pts = 300

slope = 4
std = 0.1
l = 0.5
fac = 6
t = seq(0, 1, length.out = pts)


f1 = gp1d(99, mu = sin(5*t*pi) + slope*t, sd = std, l = l, pts = pts)
f4 = gp1d(99, mu = sin(5*t*pi) + slope*t, sd = std, l = fac*l, pts = pts)
f5 = gp1d(99, mu = sin(2*t*pi) + slope*t, sd = std, l = l, pts = pts)


fw = fft(f_to_srvf(f1, t))
plot.frequency.spectrum(fw[1:50, 1])

fw = fft(f_to_srvf(f4, t))
plot.frequency.spectrum(fw[1:50, 1])

fw = fft(f_to_srvf(f5, t))
plot.frequency.spectrum(fw[1:50, 1])



plan(multiprocess)

slope = 4
std = 1
l = 0.5
fac = 6

# low sampling rate data
set.seed(1023)
pts = 30
t = seq(0, 1, length.out = pts)
f1 = gp1d(99, mu = sin(5*t*pi) + slope*t, sd = std, l = l, pts = pts)

d1 = depth.R1(f1)$amplitude
hist(d1, breaks = 100, xlab = "Amplitude depth", main = "Low sampling - no smoothing", col = "black")
skew(d1)

# low sampling + smoothing
set.seed(1023)
pts = 30
t = seq(0, 1, length.out = pts)
f1 = gp1d(99, mu = sin(5*t*pi) + slope*t, sd = std, l = l, pts = pts)
f1 = smooth.data(f1, 10)

d2 = depth.R1(f1)$amplitude
hist(d2, breaks = 100, xlab = "Amplitude depth", main = "Low sampling - moderate smoothing", col = "black")
skew(d2)

# high sampling
set.seed(1023)
pts = 150
t = seq(0, 1, length.out = pts)
f1 = gp1d(99, mu = sin(5*t*pi) + slope*t, sd = std, l = l, pts = pts)

d3 = depth.R1(f1)$amplitude
hist(d3, breaks = 100, xlab = "Amplitude depth", main = "High sampling - no smoothing", col = "black")
skew(d3)

stan = function(x) {
  (x - mean(x)) / sd(x)
}

boxplot(cbind(stan(d1), stan(d2), stan(d3)), 
        xlab = "Normalized amplitude depth distributions",
        ylab = "Normalized depth",
        main = "")

        