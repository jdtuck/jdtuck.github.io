rm(list = ls()); gc()

library(ggplot2)
library(dplyr)
library(tidyr)
# library(xtable)

setwd("/Users/trevh/research/elastic-depth/submitted/revisions2/sensitivity/out/")
files = list.files()

out_raw = readRDS(files[1])
for(f in files[-1]) {
  out_raw = rbind(out_raw, readRDS(f))
}

out = out_raw %>%
  filter(!model %in% c("pu", "saw"),
         method == "ED_A") %>%
  mutate(
    model = as.factor(model),
    model = recode(model, "au" = "Model 1",
                   "ad" = "Model 2",
                   "poly" = "Model 3",
                   "cov" = "Model 4",
                   "fu" = "Model 5",
                   "jmp" = "Model 6",
                   "pu" = "Model 7",
                   "saw" = "Model 8"),
    model = factor(model, levels = levels(model)[order(levels(model))]),
    method = recode(method, "ED_A" = "ED-A",
                    "ED_B" = "ED-B",
                    "ED_P" = "ED-P"),
    Metric = recode(metric, "tpr" = "TPR",
                    "tnr" = "TNR",
                    "ppv" = "PPV",
                    "f1" = "F1")
  )


# F1 score
f1 = out %>% 
  filter(metric == "f1") %>%
  mutate(
    metric = droplevels(metric)
  )
levels(f1$metric) = c("F1")

f1.small = f1 %>%
  select(range, model, value) %>%
  group_by(range, model) %>%
  mutate(
    mu = mean(value),
    std = sd(value),
    # lbound = max(0, mu - 2*std),
    # ubound = min(1, mu + 2*std)
    lbound = quantile(value, 0.025),
    ubound = quantile(value, 0.975)
  ) %>% ungroup()

ggplot(f1.small) +
  geom_ribbon(aes(x = range, ymin = lbound, ymax = ubound), fill = "grey", alpha = 0.5) +
  geom_line(aes(range, mu), color = "blue", size = 1) +
  geom_vline(xintercept = c(1.5, 2.25)) +
  facet_wrap(. ~ model) +
  ylab("F1 Score") +
  xlab("Boxplot IQR multiplier") +
  ylim(c(0, 1)) +
  theme_bw()
ggsave("../f1_sens_eda.png", height = 4, width = 7)



# True Positive Rate (Sensitivity)
tpr = out %>%
  filter(metric == "tpr") %>%
  mutate(
    metric = droplevels(metric)
  )
levels(tpr$metric) = c("tpr")

tpr.small = tpr %>%
  select(range, model, value) %>%
  group_by(range, model) %>%
  mutate(
    mu = mean(value),
    std = sd(value),
    lbound = quantile(value, 0.025),
    ubound = quantile(value, 0.975)
  ) %>% ungroup()

ggplot(tpr.small) +
  geom_ribbon(aes(x = range, ymin = lbound, ymax = ubound), fill = "grey", alpha = 0.5) +
  geom_line(aes(range, mu), color = "blue", size = 1) +
  geom_vline(xintercept = c(1.5, 2.25)) +
  facet_wrap(. ~ model) +
  ylab("True Positive Rate (Recall)") +
  xlab("Boxplot IQR multiplier") +
  ylim(c(0, 1)) +
  theme_bw()
ggsave("../tpr_sens.png", height = 4, width = 7)



# True Negative Rate
tnr = out %>%
  filter(metric == "tnr") %>%
  mutate(
    metric = droplevels(metric)
  )
levels(tnr$metric) = c("tnr")

tnr.small = tnr %>%
  select(range, model, value) %>%
  group_by(range, model) %>%
  mutate(
    mu = mean(value),
    std = sd(value),
    lbound = quantile(value, 0.025),
    ubound = quantile(value, 0.975)
  ) %>% ungroup() %>%
  filter(
    range > 1,
    range < 3
  )

ggplot(tnr.small) +
  geom_ribbon(aes(x = range, ymin = lbound, ymax = ubound), fill = "grey", alpha = 0.5) +
  geom_line(aes(range, mu), color = "blue", size = 1) +
  geom_vline(xintercept = c(1.5, 2), size = 0.8) +
  geom_hline(yintercept = 0.993, size = 0.8, col = "red") +
  facet_wrap(. ~ model) +
  ylab("True Negative Rate") +
  xlab("Boxplot IQR multiplier") +
  # ylim(c(0.9, 1)) +
  theme_bw()
ggsave("../tnr_sens.png", height = 4, width = 7)



# Positive Predictive Value (Recall)
ppv = out %>% 
  filter(metric == "ppv") %>%
  mutate(
    metric = droplevels(metric)
  )
levels(ppv$metric) = c("ppv")

ppv.small = ppv %>%
  select(range, model, value) %>%
  group_by(range, model) %>%
  mutate(
    mu = mean(value),
    std = sd(value),
    lbound = quantile(value, 0.025, na.rm = T),
    ubound = quantile(value, 0.975, na.rm = T)
  ) %>% ungroup()

ggplot(ppv.small) +
  geom_ribbon(aes(x = range, ymin = lbound, ymax = ubound), fill = "grey", alpha = 0.5) +
  geom_line(aes(range, mu), color = "blue", size = 1) +
  geom_vline(xintercept = c(1.3, 2.3)) +
  facet_wrap(. ~ model) +
  ylab("Positive Predictive Value (Precision)") +
  xlab("Boxplot IQR multiplier") +
  ylim(c(0, 1)) +
  theme_bw()
ggsave("../ppv_sens.png", height = 4, width = 7)


# ggplot(f1) +
#   # geom_line(aes(x = range,
#   #               y = value,
#   #               group = sim),
#   #           size = 0.8, alpha = 0.1) +
#   geom_smooth(aes(x = range, y = value), se = T) +
#   facet_wrap(. ~ model) +
#   xlab("Boxplot cutoff") +
#   ylab("Value") +
#   theme_bw()
# # ggsave("../sensitivity.png", height = 7, width = 7)
# 
# ggplot(out) +
#   geom_smooth(aes(x = range, y = value, group = Metric, color = Metric), se = F) +
#   facet_wrap(. ~ model) +
#   # ylim(c(0, 1.1)) +
#   xlab("Boxplot cutoff") +
#   ylab("Value") +
#   theme_bw()
# ggsave("../sensitivity.png", height = 7, width = 7)


