bp = function(d, k) {
  c = median(d) - k * (max(d) - median(d))
  as.numeric(d < c)
}


sims = 50
pts = 20
nfun = 50
nk = 200
nsd = 10

t = seq(0, 1, length.out = pts)
k = seq(1, 6, length.out = nk)

sds = seq(0.01, 0.5, length.out = nsd)
esd = matrix(0, sims, nsd)


out = array(0, c(sims, nk, nsd))
for(s in 1:nsd) {
  # check k range
  for(i in 1:sims) {
    tic(paste0("Sim: ", i))
    
    f = t(matrix(rnorm(nfun), nfun, pts)) + sin(2*pi*t)
    f = f + rnorm(nfun*pts, sd = sds[s])
    
    # estimate noise
    fpcs = fpca.sc(t(f), pve = 0.999)
    noise = f - t(fpcs$Yhat)
    esd[i,s] = sd(noise)
    
    # compute k range
    d = depth.R1(f)$amplitude
    
    out[i,,s] = sapply(k, function(x) mean(bp(d, x) == 0))
    
    toc()
  }
}

# esimated noise levels
boxplot(esd)


out2 = apply(out, c(2, 3), mean)
rownames(out2) = k
colnames(out2) = round(sds, 2)
out3 = melt(out2)

ggplot(out3) +
  geom_path(aes(Var1, value, group = Var2, color = as.factor(Var2)),
            size = 1) +
  geom_hline(yintercept = 0.993) +
  geom_vline(xintercept = 1.5) +
  theme_bw() +
  labs(color = "sigma",
       x = "Boxplot mulitplier k",
       y = "coverage probability")


# estimated K
# out2 = matrix(out2, 200, 10)
kmin_low = apply(out2, 2, function(x) k[which(x >= 0.993)[1]])
plot(kmin_low)





