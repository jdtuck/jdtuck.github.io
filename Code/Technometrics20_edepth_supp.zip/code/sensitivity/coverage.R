rm(list = ls()); gc()

###### Compare coverage as a function of intrinsic dimension of the data
### higher intrinsic dimensions INCREASES the inflation factor needed to fully cover the data
### Find out what the minimum values needed are, as well as the maximum. Is there a finite asymptote?

setwd("/Users/trevh/research/elastic-depth/submitted/")
setwd("/Users/trevorh2/research/elastic-depth/submitted/")

library(tictoc)
library(fdasrvf)
library(reshape2)
library(ggplot2)
library(future.apply)
library(fChange)

# simulation and depth code
source("utils.R")
source("depths.R")
source("/Users/trevorh2/research/nmfchange/code/simulation/util.R")

bp = function(d, k) {
  c = median(d) - k * (max(d) - median(d))
  as.numeric(d < c)
}

plan(multisession)

##### general setup
sims = 10
pts = 50
nfun = 100
nk = 200

t = seq(0, 1, length.out = pts)
k = seq(1, 6, length.out = nk)


##### very low dim
nbasis = 3

out = matrix(0, sims, nk)
for(i in 1:sims) {
  tic(paste0("Sim: ", i))
  
  f = fun_IID(nfun, nbasis = nbasis)
  f = approxFourier(f$coefs, pts)
  d = depth.R1(f)$amplitude
  
  out[i,] = sapply(k, function(x) mean(bp(d, x) == 0))
  
  toc()
}
kmin_low = k[which(colMeans(out) >= 0.993)[1]]

plot(k, colMeans(out), main = "Low intrinsic dimension (3 basis)")
abline(h = 0.993)
abline(v = kmin_low)



##### medium dim
nbasis = 13

out = matrix(0, sims, nk)
for(i in 1:sims) {
  tic(paste0("Sim: ", i))
  
  f = fun_IID(nfun, nbasis = nbasis)
  f = approxFourier(f$coefs, pts)
  d = depth.R1(f)$amplitude
  
  out[i,] = sapply(k, function(x) mean(bp(d, x) == 0))
  
  toc()
}
kmin_med = k[which(colMeans(out) >= 0.993)[1]]

plot(k, colMeans(out), main = "Medium intrinsic dimension (13 basis)")
abline(h = 0.993)
abline(v = kmin_med)



##### high dim
nbasis = 23

out = matrix(0, sims, nk)
for(i in 1:sims) {
  tic(paste0("Sim: ", i))
  
  f = fun_IID(nfun, nbasis = nbasis)
  f = approxFourier(f$coefs, pts)
  d = depth.R1(f)$amplitude
  
  out[i,] = sapply(k, function(x) mean(bp(d, x) == 0))
  
  toc()
}

kmin_hi = k[which(colMeans(out) >= 0.993)[1]]

plot(k, colMeans(out), main = "High intrinsic dimension (23 basis)")
abline(h = 0.993)
abline(v = kmin_hi)







