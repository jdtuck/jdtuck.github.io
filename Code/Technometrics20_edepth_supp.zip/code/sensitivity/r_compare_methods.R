rm(list = ls()); gc()

library(tictoc)
library(fdasrvf)
library(reshape2)
library(ggplot2)
library(future)
library(future.apply)
library(abind)

# simulation and depth code
setwd("/home/trevorh2/elastic/bplots")
source("/home/trevorh2/elastic/utils/sim.R")
source("/home/trevorh2/elastic/utils/depths.R")
source("/home/trevorh2/elastic/utils/plots.R")
source("/home/trevorh2/elastic/utils/utils.R")


# outlier metrics
plan(multicore)
find_outliers_rng = function(h, rng) {
  baseline = rep(0, 100)
  
  # depth boxplot
  depths = depth.R1(h)
  amp.out = vapply(rng, function(x) as.integer(bp_outliers(depths, ka = x)$amp),
                   rep(0, 100))
  
  # geom_out
  h.warp = time_warping(h, t, showplot = F, method = "median")
  geom_out = vapply(rng, function(x) {
    base = rep(0, 100)
    g_out = AmplitudeBoxplot(h.warp, showplot = F, ka = x)$outlier_index
    base[g_out] = 1
    base
  }, rep(0, 100))
  
  
  abind(amp.out = amp.out,
        geom_out = geom_out, 
        along = 3)
}

# metrics
metrics = function(est, act) {
  tab = table(est, act)
  if(nrow(tab) == 1 ) {
    if(as.numeric(rownames(tab)) == 0) {
      tab = rbind(tab, c(0, 0))
    }
    else if(as.numeric(rownames(tab)) == 1) {
      tab = rbind(c(0, 0), tab)
    }
  }
  c(tpr = tab[4] / (tab[3] + tab[4]),
    tnr = tab[1] / (tab[1] + tab[2]),
    ppv = tab[4] / (tab[2] + tab[4]),
    f1 = 2*tab[4] / (2*tab[4] + tab[2] + tab[3]))
}

# input 
args = commandArgs(TRUE)
outmodel = as.character(args[1])
phase = as.character(args[2])
trans = as.character(args[3])
batch = as.integer(args[4])

# for modifying the seed in a consistent way
str2num = function(string) {
  as.numeric(paste(match(unlist(strsplit(outmodel, "")), letters[1:26]), collapse = ""))
}

# unchanging parameters
set.seed((0723 + str2num(outmodel) + str2num(phase))*batch)
sims = 100
pts = 30

slope = 4
std = 0.5
l = 0.5
fac = 6

# intermediate variables
t = seq(0, 1, length.out = pts)
truth = c(rep(0, 90), rep(1, 10))
rng = seq(0.6, 1.8, length.out = 30)

outs = array(NA, dim = c(100, length(rng), 2, sims))

#### Simulation
for(i in 1:sims) {
  tic(paste0("sim ", i)) 
  
  # generate data according to outlier model
  if(outmodel == "au") {
    f = gp1d(90, mu = sin(5*t*pi) + slope*t, sd = std, l = l, pts = pts)
    g = gp1d(10, mu = fac/1.5*sin(5*t*pi) + slope*t, sd = std, l = l, pts = pts)
    
    if(phase == "p") {
      # add phase
      fgam = t(rgam(pts, 0.1, 90))
      ggam = t(rgam(pts, 0.1, 10))
      
      f = vapply(1:ncol(f), function(x) warp_f_gamma(f[,x], t, fgam[,x]), rep(0, pts))
      g = vapply(1:ncol(g), function(x) warp_f_gamma(g[,x], t, ggam[,x]), rep(0, pts))
    }
    
    # random shifting
    f = vapply(1:ncol(f), function(x) f[,x] + rnorm(1, sd = 1), rep(0, pts))
    g = vapply(1:ncol(g), function(x) g[,x] + rnorm(1, sd = 1), rep(0, pts))
    
    h = cbind(f, g)
  }
  if(outmodel == "ad") {
    f = gp1d(90, mu = sin(5*t*pi) + slope*t, sd = std, l = l, pts = pts)
    g = gp1d(10, mu = (1/fac)*sin(5*t*pi) + slope*t, sd = std, l = l, pts = pts)
    
    if(phase == "p") {
      # add phase
      fgam = t(rgam(pts, 0.1, 90))
      ggam = t(rgam(pts, 0.1, 10))
      
      f = vapply(1:ncol(f), function(x) warp_f_gamma(f[,x], t, fgam[,x]), rep(0, pts))
      g = vapply(1:ncol(g), function(x) warp_f_gamma(g[,x], t, ggam[,x]), rep(0, pts))
    }
    
    # random shifting
    f = vapply(1:ncol(f), function(x) f[,x] + rnorm(1, sd = 1), rep(0, pts))
    g = vapply(1:ncol(g), function(x) g[,x] + rnorm(1, sd = 1), rep(0, pts))
    
    h = cbind(f, g)
  }
  if(outmodel == "pu") {
    f = gp1d(90, mu = sin(5*t*pi) + slope*t, sd = std, l = l, pts = pts)
    g = gp1d(10, mu = sin(5*t*pi) + slope*t, sd = std, l = l, pts = pts)
    
    gam = t(rgam(pts, fac, 10))
    g = vapply(1:ncol(g), function(x) warp_f_gamma(g[,x], t, gam[,x]), rep(0, pts))
    
    h = cbind(f, g)
  }
  if(outmodel == "cov") {
    f = gp1d(90, mu = sin(5*t*pi) + slope*t, sd = std, l = fac*l, pts = pts)
    g = gp1d(10, mu = sin(5*t*pi) + slope*t, sd = std, l = l/fac, pts = pts)
    
    if(phase == "p") {
      # add phase
      fgam = t(rgam(pts, 0.1, 90))
      ggam = t(rgam(pts, 0.1, 10))
      
      f = vapply(1:ncol(f), function(x) warp_f_gamma(f[,x], t, fgam[,x]), rep(0, pts))
      g = vapply(1:ncol(g), function(x) warp_f_gamma(g[,x], t, ggam[,x]), rep(0, pts))
    }
    
    # random shifting
    f = vapply(1:ncol(f), function(x) f[,x] + rnorm(1, sd = 1), rep(0, pts))
    g = vapply(1:ncol(g), function(x) g[,x] + rnorm(1, sd = 1), rep(0, pts))
    
    h = cbind(f, g)
  }
  if(outmodel == "fu") {
    f = gp1d(90, mu = sin(2*t*pi) + slope*t, sd = std, l = l, pts = pts)
    g = gp1d(10, mu = sin(2*fac*t*pi) + slope*t, sd = std, l = l, pts = pts)
    
    if(phase == "p") {
      # add phase
      fgam = t(rgam(pts, 0.1, 90))
      ggam = t(rgam(pts, 0.1, 10))
      
      f = vapply(1:ncol(f), function(x) warp_f_gamma(f[,x], t, fgam[,x]), rep(0, pts))
      g = vapply(1:ncol(g), function(x) warp_f_gamma(g[,x], t, ggam[,x]), rep(0, pts))
    }
    
    # random shifting
    f = vapply(1:ncol(f), function(x) f[,x] + rnorm(1, sd = 1), rep(0, pts))
    g = vapply(1:ncol(g), function(x) g[,x] + rnorm(1, sd = 1), rep(0, pts))
    
    h = cbind(f, g)
  }
  if(outmodel == "fd") {
    f = gp1d(90, mu = sin(2*fac*t*pi) + slope*t, sd = std, l = l, pts = pts)
    g = gp1d(10, mu = sin(2*t*pi) + slope*t, sd = std, l = l, pts = pts)
    
    if(phase == "p") {
      # add phase
      fgam = t(rgam(pts, 0.1, 90))
      ggam = t(rgam(pts, 0.1, 10))
      
      f = vapply(1:ncol(f), function(x) warp_f_gamma(f[,x], t, fgam[,x]), rep(0, pts))
      g = vapply(1:ncol(g), function(x) warp_f_gamma(g[,x], t, ggam[,x]), rep(0, pts))
    }
    
    # random shifting
    f = vapply(1:ncol(f), function(x) f[,x] + rnorm(1, sd = 1), rep(0, pts))
    g = vapply(1:ncol(g), function(x) g[,x] + rnorm(1, sd = 1), rep(0, pts))
    
    h = cbind(f, g)
  }
  if(outmodel == "sup") {
    f = gp1d(90, mu = sin(5*t*pi) + slope*t, sd = std, l = l, pts = pts)
    g = 0.5*gp1d(10, mu = sin(2*fac*t*pi) + slope*t, sd = std, l = l, pts = pts) +
      0.5*gp1d(10, mu = sin(5*t*pi) + slope*t, sd = std, l = l, pts = pts)
    
    if(phase == "p") {
      # add phase
      fgam = t(rgam(pts, 0.1, 90))
      ggam = t(rgam(pts, 0.1, 10))
      
      f = vapply(1:ncol(f), function(x) warp_f_gamma(f[,x], t, fgam[,x]), rep(0, pts))
      g = vapply(1:ncol(g), function(x) warp_f_gamma(g[,x], t, ggam[,x]), rep(0, pts))
    }
    
    # random shifting
    f = vapply(1:ncol(f), function(x) f[,x] + rnorm(1, sd = 1), rep(0, pts))
    g = vapply(1:ncol(g), function(x) g[,x] + rnorm(1, sd = 1), rep(0, pts))
    
    h = cbind(f, g)
  }
  if(outmodel == "pk") {
    f = gp1d(90, mu = sin(5*t*pi) + slope*t, sd = std, l = l, pts = pts)
    g = gp1d(10, mu = sin(5*t*pi) + slope*t, sd = std, l = l, pts = pts)
    
    tl = round(runif(10, 0.3, 0.6) * pts, 0)
    tu = round(tl + 0.2 * pts, 0)
    
    jumps = matrix(0, pts, 10)
    for(j in 1:10) {
      jumps[seq(tl[j], tu[j]), j] = 3
    }
    g = g + jumps
    
    if(phase == "p") {
      # add phase
      fgam = t(rgam(pts, 0.1, 90))
      ggam = t(rgam(pts, 0.1, 10))
      
      f = vapply(1:ncol(f), function(x) warp_f_gamma(f[,x], t, fgam[,x]), rep(0, pts))
      g = vapply(1:ncol(g), function(x) warp_f_gamma(g[,x], t, ggam[,x]), rep(0, pts))
    }
    
    # random shifting
    f = vapply(1:ncol(f), function(x) f[,x] + rnorm(1, sd = 1), rep(0, pts))
    g = vapply(1:ncol(g), function(x) g[,x] + rnorm(1, sd = 1), rep(0, pts))
    
    h = cbind(f, g)
  }
  if(outmodel == "jmp") {
    f = gp1d(90, mu = sin(5*t*pi) + slope*t, sd = std, l = l, pts = pts)
    g = gp1d(10, mu = sin(5*t*pi) + slope*t, sd = std, l = l, pts = pts)
    
    tl = round(runif(10, 0.4, 0.6) * pts, 0)
    
    jumps = matrix(0, pts, 10)
    for(j in 1:10) {
      jumps[seq(1, tl[j]-1), j] = -2
      jumps[seq(tl[j], nrow(g)), j] = 3
    }
    g = g + jumps
    
    if(phase == "p") {
      # add phase
      fgam = t(rgam(pts, 0.1, 90))
      ggam = t(rgam(pts, 0.1, 10))
      
      f = vapply(1:ncol(f), function(x) warp_f_gamma(f[,x], t, fgam[,x]), rep(0, pts))
      g = vapply(1:ncol(g), function(x) warp_f_gamma(g[,x], t, ggam[,x]), rep(0, pts))
    }
    
    # random shifting
    f = vapply(1:ncol(f), function(x) f[,x] + rnorm(1, sd = 1), rep(0, pts))
    g = vapply(1:ncol(g), function(x) g[,x] + rnorm(1, sd = 1), rep(0, pts))
    
    h = cbind(f, g)
  }
  if(outmodel == "poly") {
    t_poly = seq(-1, 1, length.out = pts)
    
    f = gp1d(90, mu = 1*t_poly^3 - 2*t_poly^2 + 0.5*t_poly, sd = std, l = l, pts = pts)
    f = f - mean(f)
    
    g = gp1d(10, mu = 2*t_poly^3 + 1*t_poly^2 - 0.5*t_poly, sd = std, l = l, pts = pts)
    g = g - mean(g)
    
    if(phase == "p") {
      # add phase
      fgam = t(rgam(pts, 0.1, 90))
      ggam = t(rgam(pts, 0.1, 10))
      
      f = vapply(1:ncol(f), function(x) warp_f_gamma(f[,x], t, fgam[,x]), rep(0, pts))
      g = vapply(1:ncol(g), function(x) warp_f_gamma(g[,x], t, ggam[,x]), rep(0, pts))
    }
    
    # random shifting
    f = vapply(1:ncol(f), function(x) f[,x] + rnorm(1, sd = 1), rep(0, pts))
    g = vapply(1:ncol(g), function(x) g[,x] + rnorm(1, sd = 1), rep(0, pts))
    
    h = cbind(f, g)
  }
  if(outmodel == "saw") {
    t_poly = seq(-1, 1, length.out = pts)
    
    mu = c(rep(0, 10), rep(0.7, 5), rep(-0.7, 5), rep(0, 10))
    
    f = gp1d(90, mu = mu, sd = std, l = l, pts = pts)
    f = f - mean(f)
    
    g = gp1d(10, mu = 0, sd = std, l = l, pts = pts)
    g = g - mean(g)
    
    if(phase == "p") {
      # add phase
      fgam = t(rgam(pts, 0.1, 90))
      ggam = t(rgam(pts, 0.1, 10))
      
      f = vapply(1:ncol(f), function(x) warp_f_gamma(f[,x], t, fgam[,x]), rep(0, pts))
      g = vapply(1:ncol(g), function(x) warp_f_gamma(g[,x], t, ggam[,x]), rep(0, pts))
    }
    
    # random shifting
    f = vapply(1:ncol(f), function(x) f[,x] + rnorm(1, sd = 1), rep(0, pts))
    g = vapply(1:ncol(g), function(x) g[,x] + rnorm(1, sd = 1), rep(0, pts))
    
    h = cbind(f, g)
  }
  
  
  # Add translation "outliers" as bait
  if(trans == "t") {
    trans.ind = sample(1:100, size = 10, replace = F)
    
    h[,trans.ind] = vapply(trans.ind, function(x) {
      h[,x] + sample(c(-10, 10),1)
    }, FUN.VALUE = rep(0, pts))
  }
  
  # find outliers with each of the methods
  outs[,,,i] = find_outliers_rng(h, rng)
  toc()
}

f1 = apply(outs, c(2, 4, 3), function(x) metrics(x, truth))
dimnames(f1)[[4]] =  c("ED_A", "GEOM")

f2 = melt(f1)
names(f2) = c("metric", "range", "sim", "method", "value")
f2["range"] = rng
f2["model"] = outmodel
f2["phase"] = phase
f2["trans"] = trans
f2["batch"] = batch

saveRDS(f2, paste0("/home/trevorh2/elastic/revision1/sensitivity/out/out_", 
                   outmodel, "_", phase, "_", trans, "_", batch, "_.rds"))
