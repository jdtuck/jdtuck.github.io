rm(list = ls()); gc()

setwd("/Users/trevh/research/elastic-depth/submitted/")

setwd("/Users/trevorh2/research/elastic-depth/submitted/")

library(tictoc)
library(fdasrvf)
library(reshape2)
library(ggplot2)
library(future.apply)

# simulation and depth code
source("utils.R")
source("depths.R")


set.seed(1022)

# unchanging parameters
pts = 30

slope = 4
std = 0.5
l = 0.5
fac = 6
t = seq(0, 1, length.out = pts)


# Amplitude Increase
f1 = gp1d(99, mu = sin(5*t*pi) + slope*t, sd = std, l = l, pts = pts)
g1 = gp1d(1, mu = (fac/1.5)*sin(5*t*pi) + slope*t, sd = std, l = l, pts = pts)

f1 = vapply(1:ncol(f1), function(x) f1[,x] + rnorm(1, sd = 1), rep(0, pts))
# g1 = vapply(1:ncol(g1), function(x) g1[,x] + rnorm(1, sd = 1), rep(0, pts))


# Amplitude Decrease
f2 = gp1d(99, mu = sin(5*t*pi) + slope*t, sd = std, l = l, pts = pts)
g2 = gp1d(1, mu = (1/fac)*sin(5*t*pi) + slope*t, sd = std, l = l, pts = pts)

f2 = vapply(1:ncol(f2), function(x) f2[,x] + rnorm(1, sd = 1), rep(0, pts))
# g2 = vapply(1:ncol(g2), function(x) g2[,x] + rnorm(1, sd = 1), rep(0, pts))


# Phase
f3 = gp1d(99, mu = sin(5*t*pi) + slope*t, sd = std, l = l, pts = pts)
g3 = gp1d(1, mu = sin(5*t*pi) + slope*t, sd = std, l = l, pts = pts)

gam = t(rgam(pts, fac, 10))
g3 = vapply(1:ncol(g3), function(x) warp_f_gamma(g3[,x], t, gam[,x]), rep(0, pts))

f3 = vapply(1:ncol(f3), function(x) f3[,x] + rnorm(1, sd = 1), rep(0, pts))
# g3 = vapply(1:ncol(g3), function(x) g3[,x] + rnorm(1, sd = 1), rep(0, pts))


# Covariance change
f4 = gp1d(99, mu = sin(5*t*pi) + slope*t, sd = std, l = fac*l, pts = pts)
g4 = gp1d(1, mu = sin(5*t*pi) + slope*t, sd = std, l = l/fac, pts = pts)

f4 = vapply(1:ncol(f4), function(x) f4[,x] + rnorm(1, sd = 1), rep(0, pts))
# g4 = vapply(1:ncol(g4), function(x) g4[,x] + rnorm(1, sd = 1), rep(0, pts))


# Frequency Increase
f5 = gp1d(99, mu = sin(2*t*pi) + slope*t, sd = std, l = l, pts = pts)
g5 = gp1d(1, mu = sin(2*fac*t*pi) + slope*t, sd = std, l = l, pts = pts)

f5 = vapply(1:ncol(f5), function(x) f5[,x] + rnorm(1, sd = 1), rep(0, pts))
# g5 = vapply(1:ncol(g5), function(x) g5[,x] + rnorm(1, sd = 1), rep(0, pts))


# Jumps
f6 = gp1d(99, mu = sin(5*t*pi) + slope*t, sd = std, l = l, pts = pts)
g6 = gp1d(1, mu = sin(5*t*pi) + slope*t, sd = std, l = l, pts = pts)

tl = round(runif(1, 0.4, 0.6) * pts, 0)

jumps = matrix(0, pts, 1)
for(j in 1:1) {
  jumps[seq(1, tl[j]-1), j] = -2
  jumps[seq(tl[j], nrow(g6)), j] = 3
}
g6 = g6 + jumps

f6 = vapply(1:ncol(f6), function(x) f6[,x] + rnorm(1, sd = 1), rep(0, pts))
# g6 = vapply(1:ncol(g6), function(x) g6[,x] + rnorm(1, sd = 1), rep(0, pts))



# polys
t_poly = seq(-1, 1, length.out = pts)

f7 = gp1d(99, mu = 1*t_poly^3 - 2*t_poly^2 + 0.5*t_poly, sd = std, l = l, pts = pts)
f7 = f7 - mean(f7)

g7 = gp1d(1, mu = 2*t_poly^3 + 1*t_poly^2 - 0.5*t_poly, sd = std, l = l, pts = pts)
g7 = g7 - mean(g7)



### combine
f = rbind(melt(f1), melt(f2), melt(f3), melt(f4), melt(f5), melt(f6), melt(f7))
f[["time"]] = seq(0, 1, length.out = 30)
f[["Model"]] = as.factor(rep(c("Model 1 (Amplitude Increase)", "Model 2 (Amplitude Decrease)", "Model 3 (Phase)",
                               "Model 4 (Covariance)", "Model 5 (Frequency Increase)", "Model 6 (Jumps)", "Model 7 (Polynomials)"),
                             each = 99*30))

g = rbind(melt(g1), melt(g2), melt(g3), melt(g4), melt(g5), melt(g6), melt(g7))
g[["time"]] = seq(0, 1, length.out = 30)
g[["Model"]] = as.factor(rep(c("Model 1 (Amplitude Increase)", "Model 2 (Amplitude Decrease)", "Model 3 (Phase)",
                               "Model 4 (Covariance)", "Model 5 (Frequency Increase)", "Model 6 (Jumps)", "Model 7 (Polynomials)"),
                             each = 30))


### combine (amplitude only)
f = rbind(melt(f1), melt(f2), melt(f4), melt(f5), melt(f6), melt(f7))
f[["time"]] = seq(0, 1, length.out = 30)
f[["Model"]] = as.factor(rep(c("Model 1 (Amplitude Increase)", "Model 2 (Amplitude Decrease)",
                               "Model 4 (Covariance)", "Model 5 (Frequency Increase)", "Model 6 (Jumps)", "Model 7 (Polynomials)"),
                             each = 99*30))

g = rbind(melt(g1), melt(g2), melt(g4), melt(g5), melt(g6), melt(g7))
g[["time"]] = seq(0, 1, length.out = 30)
g[["Model"]] = as.factor(rep(c("Model 1 (Amplitude Increase)", "Model 2 (Amplitude Decrease)",
                               "Model 4 (Covariance)", "Model 5 (Frequency Increase)", "Model 6 (Jumps)", "Model 7 (Polynomials)"),
                             each = 30))


### combine (amplitude only)
f = rbind(melt(f1), melt(f2), melt(f7), melt(f4), melt(f5), melt(f6))
f[["time"]] = seq(0, 1, length.out = 30)
f[["Model"]] = as.factor(rep(c("Model 1 (Amplitude Increase)", 
                               "Model 2 (Amplitude Decrease)",
                               "Model 3 (Polynomials)",
                               "Model 4 (Covariance)", 
                               "Model 5 (Frequency Increase)", 
                               "Model 6 (Jumps)"),
                             each = 99*30))

g = rbind(melt(g1), melt(g2), melt(g7), melt(g4), melt(g5), melt(g6))
g[["time"]] = seq(0, 1, length.out = 30)
g[["Model"]] = as.factor(rep(c("Model 1 (Amplitude Increase)", 
                               "Model 2 (Amplitude Decrease)",
                               "Model 3 (Polynomials)",
                               "Model 4 (Covariance)", 
                               "Model 5 (Frequency Increase)", 
                               "Model 6 (Jumps)"),
                             each = 30))


ggplot() +
  theme_bw() +
  geom_line(data = f, 
            aes(time, value, group = Var2),
            color = "dodgerblue",
            alpha = 0.9,
            size = 1) +
  geom_line(data = g, 
            aes(time, value),
            color = "red",
            size = 1.2) +
  ylab("Function value") +
  xlab("Time") +
  facet_wrap(. ~ Model)
ggsave("revisions/models.png", height = 4, width = 7)
