rm(list = ls()); gc()

library(tictoc)
library(fdasrvf)
library(reshape2)
library(ggplot2)
library(future)
library(future.apply)

# other outlier detectors
library(TVD)

library(cowplot)

# simulation and depth code
setwd("../../research/elastic-depth/submitted/revisions2/code/")
setwd("../research/elastic-depth/submitted/revisions2/code/")
source("utils.R")
source("depths.R")


# outlier metrics
plan(multicore)
plan(multiprocess)


# f1score calculator
f1score = function(est, act) {
  tab = table(est, truth)
  if(nrow(tab) == 1 ) {
    if(as.numeric(rownames(tab)) == 0) {
      tab = rbind(tab, c(0, 0))
    }
    else if(as.numeric(rownames(tab)) == 1) {
      tab = rbind(c(0, 0), tab)
    }
  }
  return(2*tab[4] / (2*tab[4] + tab[2] + tab[3]))
}

# unchanging parameters
set.seed(1023)
sims = 100
pts = 30

slope = 4
std = 0.5
l = 0.5
fac = 6

# intermediate variables
t = seq(0, 1, length.out = pts)
truth = c(rep(0, 90), rep(1, 10))
out = matrix(0, sims, 3)

gam = t(rgam(pts, fac, 20))
f_mu = sin(2*t*pi)
g_mu = cos(2*t*pi)
# g_mu = warp_f_gamma(f_mu, t, gam[,2])
plt_funs(f_mu, g_mu)


for(i in 1:sims) {
  tic(paste0("sim " ,i))

  # inliers
  f = gp1d(90, mu = f_mu, sd = std, l = l, pts = pts)

  # outliers
  g = gp1d(10, mu = g_mu, sd = std, l = l, pts = pts)

  # combine
  h = cbind(f, g)

  # add translation outliers
  trans.ind = sample(1:100, size = 10, replace = F)
  h[,trans.ind] = vapply(trans.ind, function(x) {
    h[,x] + sample(c(-10, 10),1)
  }, FUN.VALUE = rep(0, pts))


  # Elastic Depth
  ed = depth.R1(h)
  ed_out = bp_outliers(ed)

  phs_out = ed_out$phs
  amp_out = ed_out$amp

  # Total Variation Depth (TVD)
  tvd = TVD::detectOutlier(h, ncol(h), nrow(h), empFactor = 1.5)$sOut
  tvd_out = rep(0, 100)
  tvd_out[tvd] = 1
  tvd_out = as.integer(tvd_out)

  out[i,] = c(f1score(amp_out, true),
              f1score(phs_out, true),
              f1score(tvd_out, true))

  toc()
}


#### results boxplot
out2 = as.data.frame(out[,2:3])
names(out2) = c("ED-P", "TVD")
out2 = melt(out2)
names(out2) = c("Method", "f1")


p2 = ggplot(out2) +
  geom_boxplot(aes(x = Method, y = f1, group = Method)) +
  geom_boxplot(data = out2[out2$Method == "ED-P",], 
               aes(x = Method, y = f1),
               color = "#F8766D") +
  ylab("F1 Score") +
  xlab("Method") +
  theme_bw() + 
  theme(text = element_text(size = 18))
print(p2)


#### data used
f = melt(f)
g = melt(g)

f[["time"]] = seq(0, 1, length.out = 30)
g[["time"]] = seq(0, 1, length.out = 30)

p1 = ggplot() +
  theme_bw() +
  geom_line(data = f, 
            aes(time, value, group = Var2),
            color = "dodgerblue",
            alpha = 0.9,
            size = 1) +
  geom_line(data = g, 
            aes(time, value, group = Var2),
            color = "red",
            size = 1.2) +
  ylab("Function value") +
  xlab("Time") + 
  theme(text = element_text(size = 18))
print(p1)

p = plot_grid(p1, p2, labels = c('A', 'B'), label_size = 12)
save_plot("../../revisions3/phase_comp.png", p, base_width = 10)
