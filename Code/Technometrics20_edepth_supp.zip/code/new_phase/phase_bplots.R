rm(list = ls()); gc()

library(tictoc)
library(fdasrvf)
library(reshape2)
library(ggplot2)
library(future)
library(future.apply)

# other outlier detectors
library(TVD)
library(CerioliOutlierDetection)

library(cowplot)

# simulation and depth code
setwd("../../research/elastic-depth/submitted/revisions2/code/")
setwd("../research/elastic-depth/submitted/revisions2/code/")
source("utils.R")
source("depths.R")


# outlier metrics
plan(multicore)
plan(multiprocess)

# Magnitude scale plot
proj.depth = function(x) {
  sdo = (x - median(x)) / mad(x)
  1 / (1 + sdo)
}
direct = function(d, x) {
  o = 1 / (d - 1)
  o = o * (x - median(x)) / sqrt(sum((x-median(x))^2))
}
ms.o = function(f) {
  apply(f, 1, function(x) direct(proj.depth(x), x))
}
ms.mo = function(f) {
  apply(ms.o(f), 1, mean)
}
ms.vo = function(f) {
  o = ms.o(f)
  mo = ms.mo(f)
  
  sapply(1:ncol(f), function(x) mean((o[x,] - mo[x])^2))
}

# directional outliers
DirOut=function(data,DirOutmatrix=FALSE,h=0.55,method="Mah"){
  temp=dim(data)
  #####################
  #Univariate cases   #
  #####################
  
  if (length(temp)==2)
  {
    
    data=t(data)
    p=dim(data)[1]
    n=dim(data)[2]
    Dirout=matrix(0,n,p)
    dmat=matrix(0,p,n)
    medvec=apply(data,1,median)
    madvec=apply(data,1,mad)
    outmat=abs((data-medvec)/(madvec))
    signmat=sign((data-medvec))
    Dirout=t(outmat*signmat)
    out_avr=apply(Dirout,1,mean)
    out_var=apply(Dirout,1,var)
    M=cbind(out_avr,out_var)
    ans=cov.rob(M,method="mcd",nsamp="best",quantile.used=floor(n*h))
    cov=ans$cov
    me=ans$center
    D=mahalanobis(M,me,cov)
  }
  
  #####################
  #Multivariate cases #
  #####################
  
  
  if (length(temp)==3)
  {
    n=temp[1]
    p=temp[2]
    d=temp[3]
    Dirout=array(0,dim=c(n,p,d))
    for (j in 1:p)
    {
      temp=covMcd(data[,j,], alpha = 0.51,control = rrcov.control(alpha=0.95))
      me=temp$center
      if (method=="Mah")
      {
        out=mahalanobis(data[,j,],temp$center,temp$cov)
      }
      
      if (method=="SDO")
      {
        out=adjOutlyingness(data[,j,],clower=0,cupper=0)$adjout
      }
      for (i in 1:n)
      {
        if ((sum((data[i,j,]-me)^2))^(1/2)==0)
        {
          Dirout[i,j,]=rep(0,d)
        }
        else{
          dir=(data[i,j,]-me)/(sum((data[i,j,]-me)^2))^(1/2)
          Dirout[i,j,]=dir*out[i]
        }
      }
    }
    out_avr=apply(Dirout,c(1,3),mean)
    out_var=apply(Dirout^2,1,mean)*d-apply(out_avr^2,1,sum)
    M=cbind(out_avr,out_var)
    ans=cov.rob(M,method="mcd",nsamp="best",quantile.used=floor(n*h))
    cov=ans$cov
    me=ans$center
    D=mahalanobis(M,me,cov)
  }
  
  if (DirOutmatrix)
    list(D=D,Dirout=Dirout,out_avr=out_avr,out_var=out_var)
  else 
    list(D=D,out_avr=out_avr,out_var=out_var)
}
dir.out = function(h) {
  DirOut(t(h))
  fac=0.154
  cutoff=6.91
  
  n=dim(t(h))[1]
  p=dim(t(h))[2]
  
  results=DirOut(t(h))
  M=cbind(results$out_avr,results$out_var)
  ans=cov.rob(M,method="mcd",nsamp="best",quantile.used=floor(n*0.55))
  cov=ans$cov
  me=ans$center
  D=mahalanobis(M,me,cov)
  num=sum(fac*D>cutoff)
  
  which(fac*D>cutoff)
}

# geomboxplots
geom.bplot = function(h) {
  h.warp = time_warping(h, t, showplot = F, method = "median")
  # AmplitudeBoxplot(h.warp, showplot = F)$outlier_index
  PhaseBoxplot(h.warp, kp = 0.6, showplot = F)$outlier_index
}

# f1score calculator
f1score = function(est, act) {
  tab = table(est, truth)
  if(nrow(tab) == 1 ) {
    if(as.numeric(rownames(tab)) == 0) {
      tab = rbind(tab, c(0, 0))
    }
    else if(as.numeric(rownames(tab)) == 1) {
      tab = rbind(c(0, 0), tab)
    }
  }
  return(2*tab[4] / (2*tab[4] + tab[2] + tab[3]))
}

# unchanging parameters
set.seed(1023)
sims = 100
pts = 30

slope = 4
std = 0.5
l = 0.5
fac = 6

# intermediate variables
t = seq(0, 1, length.out = pts)
truth = c(rep(0, 90), rep(1, 10))
out = matrix(0, sims, 6)

# # phase_comp.png
f_mu = sin(2*t*pi)
g_mu = cos(2*t*pi)
fdasrvf::elastic.distance(f_mu, g_mu, t)


# phase_bplots.png
f_mu = 5*t^3
g_mu = 5*t + rev(abs(f_mu - 5*t))
plt_funs(f_mu, g_mu)
fdasrvf::elastic.distance(f_mu, g_mu, t)


##### average phase and amplitude distance in the original simulations
f = gp1d(90, mu = sin(5*t*pi) + slope*t, sd = std, l = l, pts = pts)
g = gp1d(10, mu = sin(5*t*pi) + slope*t, sd = std, l = l, pts = pts)

gam = t(rgam(pts, fac, 10))
g = vapply(1:ncol(g), function(x) warp_f_gamma(g[,x], t, gam[,x]), rep(0, pts))

h = cbind(f, g)

fns = ncol(h)
amp_dist = matrix(0, fns, fns)
phs_dist = matrix(0, fns, fns)

for (f1 in 1:(fns-1)) {
  
  dist = future_sapply(f1:ncol(h), function(y) {
    unlist(elastic.distance(h[,f1], h[,y], t))
  })
  
  phs_dist[f1, f1:fns] = dist[2,]
  amp_dist[f1, f1:fns] = dist[1,]
}
mean(amp_dist[91:100,1:90])
mean(phs_dist[91:100,1:90])
#####

for(i in 1:sims) {
  tic(paste0("sim " ,i))
  
  # inliers
  f = gp1d(90, mu = f_mu, sd = std, l = l, pts = pts)
  
  # outliers
  g = gp1d(10, mu = g_mu, sd = std, l = l, pts = pts)
  
  # combine
  h = cbind(f, g)
  
  # add translation outliers
  trans.ind = sample(1:100, size = 10, replace = F)
  h[,trans.ind] = vapply(trans.ind, function(x) {
    h[,x] + sample(c(-10, 10),1)
  }, FUN.VALUE = rep(0, pts))
  
  
  # Elastic Depth
  ed = depth.R1(h)
  ed_out = bp_outliers(ed)
  
  phs_out = ed_out$phs
  amp_out = ed_out$amp
  
  # Total Variation Depth (TVD)
  tvd = TVD::detectOutlier(h, ncol(h), nrow(h), empFactor = 1.5)$sOut
  tvd_out = rep(0, 100)
  tvd_out[tvd] = 1
  tvd_out = as.integer(tvd_out)
  
  
  # Magnitude scale plot
  msm = ms.mo(h)
  msv = ms.vo(h)
  ms = cbind(msm, msv)
  ms = cerioli2010.irmcd.test(ms, signif.gamma = 1-0.993)$outliers
  ms_out = truth
  ms_out[ms] = 1
  ms_out = as.integer(ms_out)
  
  # directional outliers
  dir_out = rep(0, 100)
  dir_out[dir.out(h)] = 1
  
  geom_out = rep(0, 100)
  geom_out[geom.bplot(h)] = 1
  
  out[i,] = c(f1score(amp_out, truth),
              f1score(phs_out, truth),
              f1score(tvd_out, truth),
              f1score(ms_out, truth),
              f1score(dir_out, truth),
              f1score(geom_out, truth))
  
  toc()
}


#### results boxplot
out2 = as.data.frame(out[,-1])
names(out2) = c("ED-P", "TVD", "MS", "DIR", "GEOM")
out2 = melt(out2)
names(out2) = c("Method", "f1")


p2 = ggplot(out2) +
  geom_boxplot(aes(x = Method, y = f1, group = Method)) +
  geom_boxplot(data = out2[out2$Method == "ED-P",], 
               aes(x = Method, y = f1),
               color = "#F8766D") +
  ylab("F1 Score") +
  xlab("Method") +
  theme_bw() + 
  theme(text = element_text(size = 18))
print(p2)


#### data used
f = melt(f)
g = melt(g)

f[["time"]] = seq(0, 1, length.out = 30)
g[["time"]] = seq(0, 1, length.out = 30)

p1 = ggplot() +
  theme_bw() +
  geom_line(data = f, 
            aes(time, value, group = Var2),
            color = "dodgerblue",
            alpha = 0.9,
            size = 1) +
  geom_line(data = g, 
            aes(time, value, group = Var2),
            color = "red",
            size = 1.2) +
  ylab("Function value") +
  xlab("Time") + 
  theme(text = element_text(size = 18))
print(p1)

p = plot_grid(p1, p2, labels = c('A', 'B'), label_size = 12)
print(p)
save_plot("../../revisions3/phase_bplots.png", p, base_width = 10)
